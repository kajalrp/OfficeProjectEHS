﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHS.BusinessLayer
{
    public class CartBL
    {
        Training_24Oct18_PuneEntities cartDbContext = null;
        public CartBL()
        {
            cartDbContext = new Training_24Oct18_PuneEntities();
        }

        public bool AddCart(Cart cart)
        {
            bool isAdd = false;
            try
            {

                cartDbContext.Carts.Add(cart);
                int i = cartDbContext.SaveChanges();
                if (i > 0)
                    isAdd = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
        public bool RemoveCart(Cart cart)
        {
            bool isAdd = false;
            try
            {

                cartDbContext.Carts.Remove(cart);
                int i = cartDbContext.SaveChanges();
                if (i > 0)
                    isAdd = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
    }
}
