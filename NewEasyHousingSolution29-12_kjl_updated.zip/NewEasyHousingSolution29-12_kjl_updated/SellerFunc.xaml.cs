﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for SellerFunc.xaml
    /// </summary>
    public partial class SellerFunc : Window
    {
        public SellerFunc()
        {
            InitializeComponent();
        }

        ImageBL imgBL = new ImageBL();
        Picture img = new Picture();
        Property objProp = new Property();
        
        
        
        string strName, imageName;

        private void btnAddProperty(object sender, RoutedEventArgs e)
        {
            SellAddProperty SellAddPropertyObj = new SellAddProperty();
            SellAddPropertyObj.Show();
            this.Close();
        }

        
    }
}
