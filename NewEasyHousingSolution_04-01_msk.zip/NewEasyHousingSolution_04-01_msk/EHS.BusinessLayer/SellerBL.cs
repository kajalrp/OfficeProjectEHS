﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class SellerBL
    {
        Training_24Oct18_PuneEntities sellerDbContext = null;
        public static int sellerID;
        public static string sellerName;
        public SellerBL()
        {
            sellerDbContext = new Training_24Oct18_PuneEntities();
        }
        //Doing Validatioon
        public static bool ValidateSeller(Seller seller)
        {

            StringBuilder objSB = new StringBuilder();
            bool validateSeller = true;

            if (seller.FirstName == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "First Name Required");

            }
            if (seller.LastName == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Last Name Required");

            }
            string strEMail = seller.EmailId;
            Regex regx = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regx.Match(strEMail);
            if (!match.Success)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "EMail ID not Correct");

            }

            if (seller.PhoneNo.ToString().Length != 10)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Phone Number not Correct");

            }
            if (seller.Address == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Address Required");

            }
            if (seller.Password == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Password Required");

            }

            if (validateSeller == false)
            {
                throw new EHSExceptionClass(objSB.ToString());
            }

            return validateSeller;

        }

        public bool AddSeller(Seller seller)
        {
            bool isAdd = false;
            try
            {
                if (ValidateSeller(seller))
                {
                    sellerDbContext.Sellers.Add(seller);
                    int i = sellerDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }



        public IEnumerable<State> ViewState()
        {
            IQueryable<State> stateList;
            #region Linq query
            try
            {


                stateList = from statesObj in sellerDbContext.States
                            select statesObj;

                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stateList;
        }

        public int getPropertytID(string firstName)
        {
            throw new NotImplementedException();
        }

        public int getStateId(string stateName1)
        {
            State stateObj;
            List<State> stateList = sellerDbContext.States.ToList();
            try
            {
                #region
                stateObj = stateList.FirstOrDefault(st => st.StateName == stateName1);
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stateObj.StateId;
        }
        public IEnumerable<City> ViewCity()
        {
            IQueryable<City> cityList;
            #region Linq query
            try
            {


                cityList = from citiesObj in sellerDbContext.Cities

                           select citiesObj;

                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cityList;
        }
        public int getCityId(string cityName1)
        {
            City cityObj;
            List<City> cityList = sellerDbContext.Cities.ToList();
            try
            {
                #region
                cityObj = cityList.SingleOrDefault(st => st.CityName == cityName1);
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cityObj.CityId;
        }

        public int getSellerId(string name)
        {
            Seller selobj;
            List<Seller> sellerList = sellerDbContext.Sellers.ToList();
            try
            {
                selobj = sellerList.SingleOrDefault(s => s.FirstName == name);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return selobj.SellerId;
        }

        public void GetSellerId(string _sUsrId)
        {
            List<Seller> sellerList = sellerDbContext.Sellers.ToList();
            #region Linq Querry
            var id = sellerList.Single(selId => selId.UserName == _sUsrId);
            #endregion

            sellerID = id.SellerId;
        }

        public int getPropertytID(int propID)
        {
            Property objProp;
            List<Property> propList = sellerDbContext.Properties.ToList();
            try
            {
                #region
                objProp = propList.SingleOrDefault(st => st.PropertyId == propID);
                #endregion
            }
            catch (Exception e)
            {
                throw e;
            }
            return objProp.PropertyId;

        }

        /*
                public string ViewOwner()
                {
                    List<Seller> ownerList = sellerDbContext.Sellers.ToList();
                    #region Linq Querry
                    var _name = ownerList.Single(selName => selName.UserName);
                    #endregion


                    sellerName = _name.FirstName;
                    return sellerName;
                }*/

        public IEnumerable<Seller> ViewOwner()
        {
            IQueryable<Seller> ownerList;
            #region Linq query
            try
            {


                //ownerList = from objSel in sellerDbContext.Sellers
                //            select objSel.FirstName;
                ownerList = from obj in sellerDbContext.Sellers
                            select obj;

                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ownerList;
        }


    }
}