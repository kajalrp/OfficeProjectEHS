﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class 
        BuyerBL
    {
        Training_24Oct18_PuneEntities buyerDbContext = null;
        public BuyerBL()
        {
            buyerDbContext = new Training_24Oct18_PuneEntities();
        }
        //Doing Validatioon
        public static bool ValidateBuyer(Buyer buyer)
        {

            StringBuilder objSB = new StringBuilder();
            bool validateBuyer = true;

            if (buyer.FirstName == string.Empty)
            {
                validateBuyer = false;
                objSB.Append(Environment.NewLine + "First Name Required");

            }
            if (buyer.LastName == string.Empty)
            {
                validateBuyer = false;
                objSB.Append(Environment.NewLine + "Last Name Required");

            }
            if (buyer.Password == string.Empty)
            {
                validateBuyer = false;
                objSB.Append(Environment.NewLine + "Password Required");

            }
            string strEMail = buyer.EmailId;
            Regex regx = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regx.Match(strEMail);
            if (!match.Success)
            {
                validateBuyer = false;
                objSB.Append(Environment.NewLine + "EMail ID not Correct");

            }

            if (buyer.PhoneNo.ToString().Length != 10)
            {
                validateBuyer = false;
                objSB.Append(Environment.NewLine + "Phone Number not Correct");

            }




            if (validateBuyer == false)
            {
                throw new EHSExceptionClass(objSB.ToString());
            }

            return validateBuyer;

        }

        public bool AddBuyer(Buyer buyer)
        {
            bool isAdd = false;
            try
            {
                if (ValidateBuyer(buyer))
                {
                    buyerDbContext.Buyers.Add(buyer);
                    int i = buyerDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
    }
}
