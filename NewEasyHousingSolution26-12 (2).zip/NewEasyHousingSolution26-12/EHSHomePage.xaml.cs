﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for EHSHomePage.xaml
    /// </summary>
    public partial class EHSHomePage : Window
    {
        public EHSHomePage()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            UserLogin UserLoginObj = new UserLogin(); //Create object 
            UserLoginObj.Show(); 
            this.Close(); 
           
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            
            BuyOrSell BuyOrSellObj = new BuyOrSell(); //Create object 
            BuyOrSellObj.Show();
            this.Close();
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            GuestLogin GuestLoginObj = new GuestLogin();
            GuestLoginObj.Show();
            this.Close();
        }

        private void BtnAdLogin_Click(object sender, RoutedEventArgs e)
        {
            Admin AdminLoginObj = new Admin();
            AdminLoginObj.Show();
            this.Close();
        }
    }
}
