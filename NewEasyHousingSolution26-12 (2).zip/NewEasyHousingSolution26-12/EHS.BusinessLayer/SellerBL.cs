﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class SellerBL
    { 
    Training_24Oct18_PuneEntities sellerDbContext = null;

        public SellerBL()
        {
            sellerDbContext = new Training_24Oct18_PuneEntities();
        }
        //Doing Validatioon
        public static bool ValidateSeller(Seller seller)
        {

            StringBuilder objSB = new StringBuilder();
            bool validateSeller = true;

            if (seller.FirstName == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "First Name Required");

            }
            if (seller.LastName == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Last Name Required");

            }
            if (seller.EmailId == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Email Required");

            }
            else
            {
                string strEMail = seller.EmailId;
                Regex regx = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regx.Match(strEMail);
                if (!match.Success)
                {
                    validateSeller = false;
                    objSB.Append(Environment.NewLine + "EMail ID is not in correct format");

                }
            }
            if (seller.PhoneNo == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Phone number required");

            }
            if (seller.PhoneNo.ToString().Length != 10)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Phone Number should have 10 digits");

            }
            if (seller.Address == string.Empty)
            {
                validateSeller = false;
                objSB.Append(Environment.NewLine + "Address Required");

            }

            if (validateSeller == false)
            {
                throw new EHSExceptionClass(objSB.ToString());
            }

            return validateSeller;

        }

        public bool AddSeller(Seller seller)
        {
            bool isAdd = false;
            try
            {
                if (ValidateSeller(seller))
                {
                    sellerDbContext.Sellers.Add(seller);
                    int i = sellerDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
      
    }
}

