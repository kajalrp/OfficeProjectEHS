﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for SellerRegistration.xaml
    /// </summary>
    public partial class SellerRegistration : Window
    {
        public SellerRegistration()
        {
            InitializeComponent();
        }
        SellerBL buyerBL = new SellerBL();
        Seller seller = new Seller();

        private void BtnSellerRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Add();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Add()
        {
            try
            {
                //presentation layer data.
                seller.FirstName = txtSellerFirstName.Text;
                seller.LastName = txtSellerLastName.Text;
                seller.PhoneNo = txtSellerPhoneNum.Text;
                seller.DateofBirth = Convert.ToDateTime(dateSellerBirth.Text);
         
                seller.EmailId = txtSellerEmail.Text;
                seller.Address = txtSellerAddress.Text;

                //
                bool status = buyerBL.AddSeller(seller);
                if (status)
                {
                    MessageBox.Show("Congratulations!!!" +
                        "You are our new Seller");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

    }
}
