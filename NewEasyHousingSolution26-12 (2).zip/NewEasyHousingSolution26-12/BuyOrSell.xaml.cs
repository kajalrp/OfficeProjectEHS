﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for BuyOrSell.xaml
    /// </summary>
    public partial class BuyOrSell : Window
    {
        public BuyOrSell()
        {
            InitializeComponent();
        }

        private void btn_ClickSell(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ClickBuy(object sender, RoutedEventArgs e)
        {

        }
    }
}
