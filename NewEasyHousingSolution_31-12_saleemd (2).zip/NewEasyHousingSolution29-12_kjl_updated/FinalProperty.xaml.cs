﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for FinalProperty.xaml
    /// </summary>
    public partial class FinalProperty : Window
    {
        public FinalProperty()
        {
            InitializeComponent();
        }
        PropertyBL propertyBL = new PropertyBL();
        Property property = new Property();
        Cart cart = new Cart();
        CartBL cartBL = new CartBL();


        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            List<Property> propList = propertyBL.GetAllPropertyList();
            dgPropView.ItemsSource = propList;
        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            Property p = (Property)dgPropView.SelectedItem;
            
            cart.BuyerId = BuyerBL.buyerID;
            cart.PropertyId = p.PropertyId;

            bool status = cartBL.AddCart(cart);
            if (status)
                MessageBox.Show("Added to Cart");
            else
                MessageBox.Show("Still not added to Cart!!!");
        }

        private void BtnRemoveCart_Click(object sender, RoutedEventArgs e)
        {
            Property p = (Property)dgPropView.SelectedItem;

            bool status = cartBL.RemoveCart(p.PropertyId);
            if (status)
                MessageBox.Show("Removed from Cart");
            else
                MessageBox.Show("Still not removed to Cart!!!");
        }

        private void BtnAddToCart_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
