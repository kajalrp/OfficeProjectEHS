﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHS.BusinessLayer;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class LoginBL
    {
        Training_24Oct18_PuneEntities UDdbContext = null;

        public LoginBL()
        {
            UDdbContext = new Training_24Oct18_PuneEntities();
        }

        //add user details
        public bool AddUserDetails(User objUser)
        {
            bool AddUD = false;
            try
            {
                UDdbContext.Users.Add(objUser);
                int i = UDdbContext.SaveChanges();
                if (i > 0)
                {
                    AddUD = true;
                }
            }
            catch (EHSExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AddUD;
        }

        //login user

        public bool LoginSell(string userName, string password)
        {
            List<Seller> sellerList = UDdbContext.Sellers.ToList();
            bool loginSeller = false;


            try
            {
                foreach (var user in sellerList)
                {
                    if (user.UserName == userName && user.Password == password)
                        loginSeller = true;

                }
            }
            catch (EHSExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return loginSeller;
        }
        public bool LoginBuy(string userName, string password)
        {
            List<Buyer> buyerList = UDdbContext.Buyers.ToList();
            bool loginBuyer = false;
            try
            {
                foreach (var user in buyerList)
                {
                    if (user.Password == password && user.FirstName == userName)
                        loginBuyer = true;
                }
            }
            catch (EHSExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return loginBuyer;
        }
        public bool LoginAdmin(string userName, string password)
        {
            List<AdminDetail> AdminList = UDdbContext.AdminDetails.ToList();
            bool loginAdmin = false;


            try
            {
                foreach (var user in AdminList)
                {
                    if (user.username == userName && user.AdminPassword == password)
                        loginAdmin = true;

                }
            }
            catch (EHSExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return loginAdmin;
        }

    }
}
