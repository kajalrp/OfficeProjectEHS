﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Window
    {
        LoginBL logbl = new LoginBL();
        SellerBL objseller = new SellerBL();
        BuyerBL objBuyer = new BuyerBL();
        
        public UserLogin()
        {
            InitializeComponent();
        }

        //finalkajal by 29-12
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {

            string userName = txtUserName.Text;
            string pass = passPassword.Password;
            ComboBoxItem typeItem = (ComboBoxItem)cmbUserType.SelectedItem;
            //  userType = typeItem.Content.ToString();


            bool status1 = logbl.LoginSell(userName, pass);
            bool status = logbl.LoginBuy(userName, pass);

            bool status2 = logbl.LoginAdmin(userName, pass);



            if (status1)
            {

                MessageBox.Show("Login Successfully as a Seller");
                objseller.GetSellerId(txtUserName.Text);

                SellerFunc SellerFuncObj = new SellerFunc();
                SellerFuncObj.Show();
                this.Close();
            }
            else if (status)
            {

                MessageBox.Show("Login Successfully as a Buyer");
                objBuyer.GetBuyerId(txtUserName.Text);
                FinalProperty FinalPropertyObj = new FinalProperty();
                FinalPropertyObj.Show();
                this.Close();
            }
            else if (status2)
            {

                MessageBox.Show("Login Successfully as a Admin");

                BuyerRegistration BuyerRegistrationObj = new BuyerRegistration();
                BuyerRegistrationObj.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Please check your UserName or Password !!!");
            }
        }

        private void buttonRegister_Click(object sender, RoutedEventArgs e)
        {
            BuyOrSell BuyOrSellObj = new BuyOrSell();
            BuyOrSellObj.Show();
            this.Close();
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            Admin AdminLoginObj = new Admin();
            AdminLoginObj.Show();
            this.Close();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            BuyOrSell BuyOrSellObj = new BuyOrSell();
            BuyOrSellObj.Show();
            this.Close();
        }
    }
}
