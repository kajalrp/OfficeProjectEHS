﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using EHS.BusinessLayer;


namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for ImageUploadWindow.xaml
    /// </summary>
    public partial class ImageUploadWindow : Window
    {
        PropertyBL propertyBL = new PropertyBL();
        Property property = new Property();
        Seller seller = new Seller();
        ImageBL imgBL = new ImageBL();
        Picture img = new Picture();
        public ImageUploadWindow()
        {
            InitializeComponent();
        }

        string strName, imageName;

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            UserLogin UserLoginObj = new UserLogin();
            UserLoginObj.Show();
            this.Close();
        }

        private void UploadImg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileDialog fldlg = new OpenFileDialog();
                fldlg.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();
                fldlg.Filter = "Image File (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif";
                fldlg.ShowDialog();
                {
                    strName = fldlg.SafeFileName;
                    imageName = fldlg.FileName;
                    //ImageSourceConverter isc = new ImageSourceConverter();
                    //img1.SetValue(Image.SourceProperty, isc.ConvertFromString(imageName));
                    //string executable = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    img.Photo = imageName;
                    img.PropertyId = propertyBL.GetPropertyId(SellerBL.sellerID);
                    bool status = imgBL.AddImage(img);
                    if (status)
                        MessageBox.Show("Image Inserted");
                    else
                        MessageBox.Show("Image not Inserted");


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
