﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for SellAddProperty.xaml
    /// </summary>
    public partial class SellAddProperty : Window
    {
        public SellAddProperty()
        {
            InitializeComponent();
        }
        PropertyBL propertyBL = new PropertyBL();
        Property property = new Property();
        Seller seller = new Seller();

        public void Add()
        {
            try
            {
                //presentation layer data.
                property.PropertyName = txtPropertyName.Text;
                property.PropertyType = cmbPropertyType.SelectedItem.ToString();
                property.Address = txtPropertyAddress.Text;
                property.Description = txtPropertyDescribe.Text;
                property.PriceRange = Convert.ToInt32(txtPrice.Text);
                property.InitialDeposit = Convert.ToInt32(txtDeposit.Text);
                property.Landmark = txtLandmark.Text;
                property.SellerId = SellerBL.sellerID;

                //
                bool status = propertyBL.AddProperty(property);
                if (status)
                {
                    MessageBox.Show("Congratulations!!!" +
                        "You have added proprty Successfully");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


        private void BtnPropertyRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Add();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
