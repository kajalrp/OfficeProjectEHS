﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;


namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for BuyerRegistration.xaml
    /// </summary>
    public partial class BuyerRegistration : Window
    {
        public BuyerRegistration()
        {
            InitializeComponent();
        }
        BuyerBL buyerBL = new BuyerBL();
        Buyer buyer = new Buyer();
      

        public void Add()
        {
            try
            {
                //presentation layer data.
                buyer.FirstName = txtBuyerFirstName.Text;
                buyer.LastName = txtBuyerLastName.Text;
                buyer.PhoneNo = txtBuyerPhoneNum.Text;
                buyer.DateOfBirth = Convert.ToDateTime(dateBuyerBirth.Text);
                buyer.EmailId = txtBuyerEmail.Text;

                //
                bool status = buyerBL.AddBuyer(buyer);
                if (status)
                {
                    MessageBox.Show("Congratulations!!!" +
                        "You are our new Buyer");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        

       

        private void BtnBuyerRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Add();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            EHSHomePage EHSHomePageObj = new EHSHomePage(); //Create object 
            EHSHomePageObj.Show();
            this.Close();
        }
    }
}

