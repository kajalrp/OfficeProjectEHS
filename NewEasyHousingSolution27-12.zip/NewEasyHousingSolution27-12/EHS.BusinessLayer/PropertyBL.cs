﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class PropertyBL
    {
        Training_24Oct18_PuneEntities propertyDbContext = null;
        public PropertyBL()
        {
            propertyDbContext = new Training_24Oct18_PuneEntities();
        }
        //Doing Validatioon
        public static bool ValidateProperty(Property property)
        {

            StringBuilder objSB = new StringBuilder();
            bool ValidateProperty = true;

            if (property.PropertyName == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Property Name Required");

            }
            if (property.PropertyType == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Proprty Type Required, select from combobox");

            }
            if (property.Address == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "address Required");

            }
            if (property.Description == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Desciption required");

            }
            if (property.PriceRange.ToString() == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "select Property price range first");

            }
            if (property.Landmark == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Landmark required");

            }






            if (ValidateProperty == false)
            {
                throw new EHSExceptionClass(objSB.ToString());
            }

            return ValidateProperty;

        }

        public bool AddProperty(Property property)
        {
            bool isAdd = false;
            try
            {
                if (ValidateProperty(property))
                {
                    propertyDbContext.Propertys.Add(property);
                    int i = propertyDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
    }
}
}
