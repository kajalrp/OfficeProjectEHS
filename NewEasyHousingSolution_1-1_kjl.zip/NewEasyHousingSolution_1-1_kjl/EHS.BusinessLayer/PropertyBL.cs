﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{
    public class PropertyBL
    {
        Training_24Oct18_PuneEntities propertyDbContext = null;
        public static int propertyID;
        public PropertyBL()
        {
            propertyDbContext = new Training_24Oct18_PuneEntities();
        }
        //Doing Validatioon
        public static bool ValidateProperty(Property property)
        {

            StringBuilder objSB = new StringBuilder();
            bool ValidateProperty = true;

            if (property.PropertyName == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Property Name Required");

            }
           
            if (property.Address == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "address Required");

            }
            if (property.Description == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Desciption required");

            }
            if (property.PriceRange.ToString() == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + " Property price  required");

            }
            if (property.Landmark == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Landmark required");

            }
            if (property.InitialDeposit.ToString() == string.Empty)
            {
                ValidateProperty = false;
                objSB.Append(Environment.NewLine + "Initial Deposit required");

            }

            
            if (ValidateProperty == false)
            {
                throw new EHSExceptionClass(objSB.ToString());
            }

            return ValidateProperty;

        }

        public bool AddProperty(Property property)
        {
            bool isAdd = false;
            try
            {
                if (ValidateProperty(property))
                {
                    propertyDbContext.Properties.Add(property);
                    int i = propertyDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
        public int GetPropertyId(int sellerID1)
        {
            
            List<Property> propertyList = propertyDbContext.Properties.ToList();

            #region Linq Querry
            var id = propertyList.SingleOrDefault(propId => propId.SellerId == sellerID1);
                #endregion

            return id.PropertyId;
        }

        public List<Property> GetAllPropertyList()
        {
            var listProp = (from prop in propertyDbContext.Properties
                           select prop).ToList();
            return listProp;
        }
    }
}

