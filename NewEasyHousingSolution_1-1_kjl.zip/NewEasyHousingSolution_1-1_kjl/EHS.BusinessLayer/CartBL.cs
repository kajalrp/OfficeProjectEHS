﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHS.BusinessLayer
{
    public class CartBL
    {
        Training_24Oct18_PuneEntities cartDbContext = null;
        public CartBL()
        {
            cartDbContext = new Training_24Oct18_PuneEntities();
        }

        public bool AddCart(Cart cart)
        {
            bool isAdd = false;
            try
            {

                cartDbContext.Carts.Add(cart);
                int i = cartDbContext.SaveChanges();
                if (i > 0)
                    isAdd = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
        public bool RemoveCart(int propId)
        {
            bool isAdd = false;
            try
            {
                var idProp = from s in cartDbContext.Carts
                             where s.PropertyId == propId
                             select s;
                foreach (Cart c in idProp)
                {
                    cartDbContext.Carts.Remove(c);
                }
                int i = cartDbContext.SaveChanges();
                if (i > 0)
                    isAdd = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
    }
}
