﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for SellAddProperty.xaml
    /// </summary>
    public partial class SellAddProperty : Window
    {
        public SellAddProperty()
        {
            InitializeComponent();
        }
        PropertyBL propertyBL = new PropertyBL();
        Property property = new Property();
        Seller seller = new Seller();
        ImageBL imgBL = new ImageBL();
        Picture img = new Picture();


        public void Add()
        {
            try
            {
                //presentation layer data.
                ComboBoxItem typeItem = (ComboBoxItem)cmbPropertyType.SelectedItem;
                property.PropertyName = txtPropertyName.Text;
                property.PropertyType = typeItem.Content.ToString();
                property.Address = txtPropertyAddress.Text;
                property.Description = txtPropertyDescribe.Text;
                property.PriceRange = Convert.ToInt32(txtPrice.Text);
                property.InitialDeposit = Convert.ToInt32(txtDeposit.Text);
                property.Landmark = txtLandmark.Text;
                property.SellerId = SellerBL.sellerID;

                //
                bool status = propertyBL.AddProperty(property);
                if (status)
                {
                    MessageBoxResult msgRes= MessageBox.Show("Congratulations!!!" +
                        "You have added proprty Successfully",MessageBoxButton.OK.ToString());
                    if(msgRes == MessageBoxResult.OK)
                    {
                        MessageBoxResult res = MessageBox.Show("Do you want to upload Images of your property?","Question", MessageBoxButton.YesNo);
                        if(res == MessageBoxResult.Yes)
                        {
                            //image upload code
                            ImageUploadWindow imgWin = new ImageUploadWindow();
                            imgWin.Show();

                        }
                        else
                        {
                            MessageBox.Show("Thank you !!! ");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


        private void BtnPropertyRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Add();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            UserLogin UserLoginObj = new UserLogin();
            UserLoginObj.Show();
            this.Close();
        }
    }
}
