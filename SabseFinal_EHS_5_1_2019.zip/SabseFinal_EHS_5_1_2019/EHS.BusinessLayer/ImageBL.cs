﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHS.Exceptions;

namespace EHS.BusinessLayer
{

   public class ImageBL
    {
        Training_24Oct18_PuneEntities imageDbContext = null;
        public ImageBL()
        {
            imageDbContext = new Training_24Oct18_PuneEntities();
        }
        public bool AddImage(Picture img)
        {
            bool isAdd = false;
            try
            {

                imageDbContext.Pictures.Add(img);
                    int i = imageDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }
    }
}
