﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHS.Exceptions
{
    public class EHSExceptionClass : ApplicationException
    {
        public EHSExceptionClass() : base()
        {

        }

        public EHSExceptionClass(string message) : base(message)
        {

        }

        public EHSExceptionClass(string message, Exception objEx) : base(message, objEx)
        {

        }
    }
}
