﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHS.BusinessLayer;

namespace EasyHousingSolution
{
    /// <summary>
    /// Interaction logic for SellerRegistration.xaml
    /// </summary>
    public partial class SellerRegistration : Window
    {
        public SellerRegistration()
        {
            InitializeComponent();
            cmbSellerState.ItemsSource = sellerBL.ViewState().ToList();
            cmbSellerState.DisplayMemberPath = "StateName";
            cmbSellerCity.ItemsSource = sellerBL.ViewCity().ToList();
            cmbSellerCity.DisplayMemberPath = "CityName";
        }
        SellerBL sellerBL = new SellerBL();
        Seller seller = new Seller();
        State state = new State();
        City city = new City();

        private void BtnSellerRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Add();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Add()
        {
            try
            {

                //presentation layer data.
                seller.UserName = txtSellerName.Text;
                seller.FirstName = txtSellerFirstName.Text;
                seller.LastName = txtSellerLastName.Text;
                seller.PhoneNo = txtSellerPhoneNum.Text;
                seller.DateofBirth = Convert.ToDateTime(dateSellerBirth.Text);
                seller.EmailId = txtSellerEmail.Text;
                seller.Address = txtSellerAddress.Text;
                State st = (State)cmbSellerState.SelectedValue;
                seller.StateId = sellerBL.getStateId(st.StateName);
                City ct = (City)cmbSellerCity.SelectedValue;
                seller.CityId = sellerBL.getCityId(ct.CityName);


                bool status = sellerBL.AddSeller(seller);
                if (status)
                {
                    MessageBox.Show("Congratulations!!!" +
                        "You are our new Seller");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

      

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            SellerFunc SellerFuncObj = new SellerFunc();
            SellerFuncObj.Show();
            this.Close();
        }
    }
}